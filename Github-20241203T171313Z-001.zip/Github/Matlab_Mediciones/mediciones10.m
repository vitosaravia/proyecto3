% Datos empíricos para -10° (todas las mediciones)
datos_10 = {
    [0.21, 0.000; 0.26, 0.004; 0.31, 0.004; 0.37, 0.027; 0.42, 0.027; 0.47, 0.061; 0.52, 0.061; 0.57, 0.103; 0.63, 0.103; 0.68, 0.153; 0.73, 0.153; 0.78, 0.219; 0.83, 0.219; 0.89, 0.282; 0.94, 0.328; 0.99, 0.328; 1.04, 0.347; 1.10, 0.347; 1.15, 0.346; 1.20, 0.346; 1.25, 0.353; 1.30, 0.353; 1.36, 0.344; 1.41, 0.344; 1.46, 0.350; 1.51, 0.350; 1.57, 0.345; 1.62, 0.345; 1.67, 0.351; 1.72, 0.348; 1.77, 0.348; 1.83, 0.351; 1.88, 0.351; 1.93, 0.374; 1.98, 0.374],
    [0.52, 0.000; 0.57, 0.018; 0.63, 0.018; 0.68, 0.054; 0.73, 0.054; 0.78, 0.092; 0.84, 0.133; 0.89, 0.133; 0.94, 0.209; 0.99, 0.209; 1.04, 0.262; 1.10, 0.262; 1.15, 0.317; 1.20, 0.317; 1.25, 0.344; 1.30, 0.344; 1.36, 0.337; 1.41, 0.337; 1.46, 0.345; 1.51, 0.345; 1.57, 0.344; 1.62, 0.345; 1.67, 0.345; 1.72, 0.337; 1.77, 0.337; 1.83, 0.346; 1.88, 0.346; 1.93, 0.341; 1.98, 0.341],
    [0.00, 0.000; 0.05, 0.001; 0.10, 0.001; 0.16, 0.017; 0.21, 0.017; 0.26, 0.046; 0.31, 0.046; 0.37, 0.085; 0.42, 0.085; 0.47, 0.125; 0.52, 0.125; 0.57, 0.191; 0.63, 0.191; 0.68, 0.249; 0.73, 0.306; 0.78, 0.306; 0.83, 0.340; 0.89, 0.340; 0.94, 0.338; 0.99, 0.338; 1.04, 0.342; 1.10, 0.342; 1.15, 0.345; 1.20, 0.345; 1.25, 0.342; 1.30, 0.342; 1.36, 0.346; 1.41, 0.346; 1.46, 0.369; 1.51, 0.382; 1.57, 0.382; 1.62, 0.383; 1.67, 0.383; 1.72, 0.383; 1.77, 0.383; 1.83, 0.378; 1.88, 0.378; 1.93, 0.379; 1.98, 0.379],
    [0.57, 0.000; 0.63, 0.005; 0.68, 0.005; 0.73, 0.033; 0.78, 0.033; 0.83, 0.077; 0.89, 0.117; 0.94, 0.117; 0.99, 0.170; 1.04, 0.170; 1.10, 0.239; 1.15, 0.239; 1.20, 0.293; 1.25, 0.293; 1.30, 0.336; 1.36, 0.336; 1.41, 0.340; 1.46, 0.340; 1.51, 0.344; 1.57, 0.344; 1.62, 0.345; 1.67, 0.343; 1.72, 0.343; 1.77, 0.342; 1.83, 0.342; 1.88, 0.342; 1.93, 0.342; 1.98, 0.341],
    [0.42, 0.000; 0.47, 0.002; 0.52, 0.002; 0.57, 0.016; 0.63, 0.016; 0.68, 0.051; 0.73, 0.051; 0.78, 0.091; 0.83, 0.091; 0.89, 0.135; 0.94, 0.135; 0.99, 0.204; 1.04, 0.204; 1.10, 0.259; 1.15, 0.316; 1.20, 0.316; 1.25, 0.347; 1.30, 0.347; 1.36, 0.337; 1.41, 0.337; 1.46, 0.343; 1.51, 0.343; 1.57, 0.337; 1.62, 0.337; 1.67, 0.351; 1.72, 0.351; 1.77, 0.372; 1.83, 0.372; 1.88, 0.375; 1.93, 0.376; 1.98, 0.376]
};

% Ajustar tiempos y distancias
tiempos_ajustados = cellfun(@(x) x(:, 1) - x(1, 1), datos_10, 'UniformOutput', false);
distancias_ajustadas = cellfun(@(x) x(:, 2) - x(1, 2) - 0.2, datos_10, 'UniformOutput', false);

% Crear un tiempo común
tiempo_comun = linspace(0, max(cellfun(@max, tiempos_ajustados)), 200);

% Interpolar y calcular la media
distancia_interpolada = cellfun(@(t, d) interp1(t, d, tiempo_comun, 'linear', 'extrap'), ...
                                tiempos_ajustados, distancias_ajustadas, 'UniformOutput', false);
distancia_promedio = mean(cell2mat(distancia_interpolada'), 2);

% Suavizar la línea promedio
distancia_promedio_suavizada = smoothdata(distancia_promedio, 'gaussian', 15);

% Graficar
figure;
hold on;

% Graficar mediciones individuales
for i = 1:numel(datos_10)
    plot(tiempos_ajustados{i}, distancias_ajustadas{i}, 'LineWidth', 1.5, ...
         'DisplayName', sprintf('Medición %d', i));
end

% Graficar línea promedio suavizada en negro
plot(tiempo_comun, distancia_promedio_suavizada, 'k', 'LineWidth', 2.5, ...
     'DisplayName', 'Promedio Suavizado');

% Configuración del gráfico
title('Mediciones empíricas con línea promedio (-10°)', 'FontSize', 14);
xlabel('Tiempo ajustado (s)', 'FontSize', 12);
ylabel('Distancia ajustada (m)', 'FontSize', 12);
legend('Location', 'best', 'FontSize', 10);
grid on;

% Ajustar los límites de los ejes
xlim([0, max(tiempo_comun)]);
ylim([-0.2, 0.2]);

hold off;
