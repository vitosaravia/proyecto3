% Datos empíricos para -15° (todas las mediciones)
datos_15 = {
    [0.42, 0.000; 0.47, 0.000; 0.52, 0.025; 0.57, 0.025; 0.63, 0.069; 0.68, 0.069; 0.73, 0.121; 0.78, 0.121; 0.83, 0.200; 0.89, 0.200; 0.94, 0.272; 0.99, 0.272; 1.04, 0.326; 1.10, 0.326; 1.15, 0.341; 1.20, 0.341; 1.25, 0.344; 1.30, 0.344; 1.36, 0.345; 1.41, 0.349; 1.46, 0.349; 1.51, 0.348; 1.57, 0.348; 1.62, 0.346; 1.67, 0.346; 1.72, 0.350; 1.77, 0.350; 1.83, 0.353; 1.88, 0.353; 1.93, 0.366; 1.98, 0.366],
    [0.57, 0.000; 0.63, 0.000; 0.68, 0.025; 0.73, 0.025; 0.78, 0.070; 0.83, 0.070; 0.89, 0.125; 0.94, 0.125; 0.99, 0.196; 1.04, 0.196; 1.09, 0.270; 1.15, 0.330; 1.20, 0.330; 1.25, 0.345; 1.30, 0.345; 1.36, 0.341; 1.41, 0.341; 1.46, 0.348; 1.51, 0.348; 1.56, 0.344; 1.62, 0.344; 1.67, 0.348; 1.72, 0.348; 1.77, 0.334; 1.83, 0.334; 1.88, 0.353; 1.93, 0.363; 1.98, 0.363],
    [0.42, 0.000; 0.47, 0.004; 0.52, 0.004; 0.57, 0.032; 0.63, 0.032; 0.68, 0.078; 0.73, 0.078; 0.78, 0.134; 0.83, 0.134; 0.89, 0.214; 0.94, 0.214; 0.99, 0.285; 1.04, 0.285; 1.10, 0.342; 1.15, 0.342; 1.20, 0.343; 1.25, 0.348; 1.30, 0.348; 1.36, 0.338; 1.41, 0.338; 1.46, 0.323; 1.51, 0.323; 1.57, 0.339; 1.62, 0.339; 1.67, 0.347; 1.72, 0.347; 1.77, 0.346; 1.83, 0.346; 1.88, 0.343; 1.93, 0.343; 1.98, 0.354],
    [0.47, 0.000; 0.52, 0.000; 0.57, 0.002; 0.63, 0.032; 0.68, 0.032; 0.73, 0.081; 0.78, 0.081; 0.83, 0.131; 0.89, 0.131; 0.94, 0.217; 0.99, 0.217; 1.04, 0.293; 1.10, 0.293; 1.15, 0.344; 1.20, 0.344; 1.25, 0.344; 1.30, 0.344; 1.36, 0.348; 1.41, 0.345; 1.46, 0.345; 1.51, 0.343; 1.56, 0.343; 1.62, 0.320; 1.67, 0.320; 1.72, 0.295; 1.77, 0.295; 1.83, 0.331; 1.88, 0.331; 1.93, 0.356; 1.98, 0.356],
    [0.52, 0.000; 0.57, 0.000; 0.63, 0.015; 0.68, 0.015; 0.73, 0.057; 0.78, 0.057; 0.83, 0.108; 0.89, 0.108; 0.94, 0.178; 0.99, 0.259; 1.04, 0.259; 1.10, 0.323; 1.15, 0.323; 1.20, 0.342; 1.25, 0.342; 1.30, 0.345; 1.36, 0.345; 1.41, 0.348; 1.46, 0.348; 1.51, 0.349; 1.57, 0.349; 1.62, 0.341; 1.67, 0.341; 1.72, 0.345; 1.77, 0.342; 1.83, 0.342; 1.88, 0.357; 1.93, 0.357; 1.98, 0.366]
};

% Ajustar tiempos y distancias
tiempos_ajustados = cellfun(@(x) x(:, 1) - x(1, 1), datos_15, 'UniformOutput', false);
distancias_ajustadas = cellfun(@(x) x(:, 2) - x(1, 2) - 0.2, datos_15, 'UniformOutput', false);

% Crear un tiempo común
tiempo_comun = linspace(0, max(cellfun(@max, tiempos_ajustados)), 200);

% Interpolación y cálculo del promedio
distancia_interpolada = cellfun(@(t, d) interp1(t, d, tiempo_comun, 'linear', 'extrap'), ...
                                tiempos_ajustados, distancias_ajustadas, 'UniformOutput', false);
distancia_promedio = mean(cell2mat(distancia_interpolada'), 2);

% Suavizar la línea promedio
distancia_promedio_suavizada = smoothdata(distancia_promedio, 'gaussian', 15);

% Graficar
figure;
hold on;

% Graficar las mediciones individuales
for i = 1:numel(datos_15)
    plot(tiempos_ajustados{i}, distancias_ajustadas{i}, 'LineWidth', 1.5, ...
         'DisplayName', sprintf('Medición %d', i));
end

% Graficar línea promedio suavizada en negro
plot(tiempo_comun, distancia_promedio_suavizada, 'k', 'LineWidth', 2.5, ...
     'DisplayName', 'Promedio Suavizado');

% Configuración del gráfico
title('Mediciones empíricas con línea promedio (-15°)', 'FontSize', 14);
xlabel('Tiempo ajustado (s)', 'FontSize', 12);
ylabel('Distancia ajustada (m)', 'FontSize', 12);
legend('Location', 'best', 'FontSize', 10);
grid on;

% Ajustar límites de los ejes
xlim([0, max(tiempo_comun)]);
ylim([-0.2, 0.2]);

hold off;
