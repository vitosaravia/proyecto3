% Datos empíricos para -5° (todas las mediciones)
datos = {
    [0.16, 0.000; 0.21, 0.001; 0.26, 0.001; 0.31, 0.009; 0.37, 0.009; 0.42, 0.029; 0.47, 0.056; 0.52, 0.056; 0.57, 0.079; 0.63, 0.079; 0.68, 0.113; 0.73, 0.113; 0.78, 0.140; 0.84, 0.140; 0.89, 0.187; 0.94, 0.187; 0.99, 0.225; 1.04, 0.225; 1.10, 0.263; 1.15, 0.263; 1.20, 0.295; 1.25, 0.325; 1.30, 0.325; 1.36, 0.331; 1.41, 0.331; 1.46, 0.331; 1.51, 0.331; 1.57, 0.337; 1.62, 0.337; 1.67, 0.342; 1.72, 0.342; 1.77, 0.332; 1.83, 0.332; 1.88, 0.327; 1.93, 0.327; 1.98, 0.337],
    [0.47, 0.000; 0.52, 0.010; 0.57, 0.010; 0.63, 0.029; 0.68, 0.029; 0.73, 0.051; 0.78, 0.051; 0.83, 0.080; 0.89, 0.110; 0.94, 0.110; 0.99, 0.139; 1.04, 0.139; 1.10, 0.187; 1.15, 0.187; 1.20, 0.227; 1.25, 0.227; 1.30, 0.269; 1.36, 0.269; 1.41, 0.302; 1.46, 0.302; 1.51, 0.317; 1.57, 0.317; 1.62, 0.343; 1.67, 0.335; 1.72, 0.335; 1.77, 0.330; 1.83, 0.330; 1.88, 0.341; 1.93, 0.341; 1.98, 0.338],
    [0.16, 0.000; 0.21, 0.003; 0.26, 0.003; 0.31, 0.019; 0.37, 0.019; 0.42, 0.043; 0.47, 0.043; 0.52, 0.068; 0.57, 0.068; 0.63, 0.095; 0.68, 0.095; 0.73, 0.120; 0.78, 0.164; 0.83, 0.164; 0.89, 0.206; 0.94, 0.206; 0.99, 0.243; 1.04, 0.243; 1.10, 0.280; 1.15, 0.280; 1.20, 0.316; 1.25, 0.316; 1.30, 0.330; 1.36, 0.330; 1.41, 0.332; 1.46, 0.332; 1.51, 0.324; 1.57, 0.339; 1.62, 0.339; 1.67, 0.333; 1.72, 0.333; 1.77, 0.346; 1.83, 0.346; 1.88, 0.336; 1.93, 0.336; 1.98, 0.333],
    [0.68, 0.000; 0.73, 0.006; 0.78, 0.006; 0.83, 0.021; 0.89, 0.021; 0.94, 0.042; 0.99, 0.070; 1.04, 0.070; 1.10, 0.096; 1.15, 0.096; 1.20, 0.127; 1.25, 0.127; 1.30, 0.169; 1.36, 0.169; 1.41, 0.214; 1.46, 0.214; 1.51, 0.246; 1.57, 0.246; 1.62, 0.285; 1.67, 0.285; 1.72, 0.312; 1.77, 0.341; 1.83, 0.341; 1.88, 0.327; 1.93, 0.327; 1.98, 0.331],
    [0.00, 0.000; 0.05, 0.000; 0.10, 0.006; 0.16, 0.006; 0.21, 0.023; 0.26, 0.023; 0.31, 0.048; 0.36, 0.048; 0.42, 0.075; 0.47, 0.106; 0.52, 0.106; 0.57, 0.133; 0.63, 0.133; 0.68, 0.180; 0.73, 0.180; 0.78, 0.219; 0.83, 0.219; 0.89, 0.256; 0.94, 0.256; 0.99, 0.293; 1.04, 0.293; 1.10, 0.319; 1.15, 0.319; 1.20, 0.327; 1.25, 0.328; 1.30, 0.328; 1.36, 0.335; 1.41, 0.335; 1.46, 0.331; 1.51, 0.331; 1.57, 0.335; 1.62, 0.335; 1.67, 0.331; 1.72, 0.331; 1.77, 0.330; 1.83, 0.330; 1.88, 0.334; 1.93, 0.334; 1.98, 0.332]
};

% Ajustar tiempos y distancias para cada medición
tiempos_ajustados = cellfun(@(x) x(:, 1) - x(1, 1), datos, 'UniformOutput', false);
distancias_ajustadas = cellfun(@(x) x(:, 2) - x(1, 2) - 0.2, datos, 'UniformOutput', false);

% Crear un tiempo común para todas las mediciones
tiempo_comun = linspace(0, max(cellfun(@max, tiempos_ajustados)), 200);

% Interpolar y calcular la media
distancia_interpolada = cellfun(@(t, d) interp1(t, d, tiempo_comun, 'linear', 'extrap'), ...
                                tiempos_ajustados, distancias_ajustadas, 'UniformOutput', false);
distancia_promedio = mean(cell2mat(distancia_interpolada'), 2);

% Suavizar la línea promedio
distancia_promedio_suavizada = smoothdata(distancia_promedio, 'gaussian', 15);

% Graficar
figure;
hold on;

% Graficar las mediciones individuales
for i = 1:numel(datos)
    plot(tiempos_ajustados{i}, distancias_ajustadas{i}, 'LineWidth', 1.5, ...
         'DisplayName', sprintf('Medición %d', i));
end

% Graficar la línea promedio suavizada
plot(tiempo_comun, distancia_promedio_suavizada, 'k', 'LineWidth', 2.5, ...
     'DisplayName', 'Promedio Suavizado');

% Configuración del gráfico
title('Mediciones empíricas con línea promedio (-5°)', 'FontSize', 14);
xlabel('Tiempo ajustado (s)', 'FontSize', 12);
ylabel('Distancia ajustada (m)', 'FontSize', 12);
legend('Location', 'best', 'FontSize', 10);
grid on;

% Ajustar los límites de los ejes
xlim([0, max(tiempo_comun)]);
ylim([-0.2, 0.2]);

hold off;

